# Auguste's Documentation

# Make a new app

Make a new app in the dashboard.

1. Copy the app_template and rename the folder.
2. Rename the HTML file in /templates to <the folder's name>.html
3. Modify the config params in __init__.py, set a display name and color for your app.

# Posting a form (data-bind Knockout.JS)

1. 

# Posting data through AJAX

1.

# Post array to tweepy
[u'#opsoro']
bij elke post eerst Twitter stream stoppen


# Investigate Tweepy Response
response object

# Send Tweepy object to JS -> python Users socket
Alter js funtions to pass in tweet text
Custom addLine() function

# Autoloop voicelines
import opsoro/sound lib
recursieve functie met index_voiceline++ wachten op soundStopped
Start - Post to Python - Response from Python - Running, Next - Stop?

$root.prop != $root.prop() -> runs at start

# Locked = true for lay-out

# JS loop to Python loop with Stoppable Thread

# Convert social username to ID

# Issues

Zie pics

