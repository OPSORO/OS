function setup()
	-- Called once, when the script is started
	print("Hello World!")
end

function loop()
	-- Called repeatedly, put your main program here

end

function quit()
	-- Called when the script is stopped

end
