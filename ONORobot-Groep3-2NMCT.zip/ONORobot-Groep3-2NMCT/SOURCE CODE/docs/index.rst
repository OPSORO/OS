.. OPSORO documentation master file, created by
   sphinx-quickstart on Mon Dec 19 15:59:45 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to OPSORO's documentation!
==================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   development/index.rst
   development/commenting.rst
   opsoro


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
