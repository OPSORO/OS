OPSORO OS
==============

Modules
-------

.. toctree::

    modules/index.rst


.. _sec-opsoro:

Module contents
---------------

.. automodule:: opsoro
    :members:
    :undoc-members:
    :show-inheritance:
