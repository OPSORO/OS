.. _sec-modules-module:

opsoro.module
----------------

.. automodule:: opsoro.module
    :members:
    :undoc-members:
    :show-inheritance:


.. _sec-modules-module-eye:

opsoro.module.eye
-----------------

.. automodule:: opsoro.module.eye
    :members:
    :undoc-members:
    :show-inheritance:


.. _sec-modules-module-eyebrow:

opsoro.module.eyebrow
---------------------

.. automodule:: opsoro.module.eyebrow
    :members:
    :undoc-members:
    :show-inheritance:


.. _sec-modules-module-mouth:

opsoro.module.mouth
-------------------

.. automodule:: opsoro.module.mouth
    :members:
    :undoc-members:
    :show-inheritance:


.. _sec-modules-module-rotation:

opsoro.module.rotation
-----------------------------

.. automodule:: opsoro.module.rotation
    :members:
    :undoc-members:
    :show-inheritance:
