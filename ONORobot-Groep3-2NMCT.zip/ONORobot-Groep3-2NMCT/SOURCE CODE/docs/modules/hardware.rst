.. _sec-modules-hardware:

opsoro.hardware
---------------

.. automodule:: opsoro.hardware
    :members:
    :undoc-members:
    :show-inheritance:


.. _sec-modules-hardware-i2c:

opsoro.hardware.i2c
-------------------

.. automodule:: opsoro.hardware.i2c
    :members:
    :undoc-members:
    :show-inheritance:
