.. _sec-modules-preferences:

opsoro.preferences
------------------

.. automodule:: opsoro.preferences
    :members:
    :undoc-members:
    :show-inheritance:
