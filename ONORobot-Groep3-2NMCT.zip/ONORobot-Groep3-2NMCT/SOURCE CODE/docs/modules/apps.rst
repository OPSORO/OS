.. _sec-modules-apps:

opsoro.apps
-----------

.. automodule:: opsoro.apps
    :members:
    :undoc-members:
    :show-inheritance:
