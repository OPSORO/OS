.. _sec-modules-sound:

opsoro.sound
------------

.. automodule:: opsoro.sound
    :members:
    :undoc-members:
    :show-inheritance:


.. _sec-modules-sound-tts:

opsoro.sound.tts
----------------

.. automodule:: opsoro.sound.tts
    :members:
    :undoc-members:
    :show-inheritance:
